
  # InnoHealth

  This is a code bundle for InnoHealth. The original project is available at https://www.figma.com/design/EGfkvOT9OudlDXdJ6KOy7L/InnoHealth.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  